SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'sys/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2
ui_print "
┏━━━┳━━━┳━┓┏━┓
┃┏━┓┃┏━┓┃┃┗┛┃┃
┃┃╋┗┫┗━━┫┏┓┏┓┃
┃┃┏━╋━━┓┃┃┃┃┃┃
┃┗┻━┃┗━┛┃┃┃┃┃┃
┗━━━┻━━━┻┛┗┛┗┛ORIGINAL
┏━━━┓****┏━━┓
┃┏━┓┃****┗┫┣┛
┃┃╋┃┃****╋┃┃
┃┗━┛┃****╋┃┃
┃┏━┓┣****┳┫┣┓
┗┛╋┗┻****┻━━┛   "
ui_print "▌VERSION : 7 "
ui_print "▌CODENAME - J.A.R.V.I.S 2.4 "
sleep 1
ui_print "▌DEVICE INFORMATION: "
sleep 0.2
ui_print "▌DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "▌BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "▌MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "▌KERNEL : $(uname -r) "
sleep 0.2
ui_print "▌PROCESSOR : $(getprop ro.product.board) "
ui_print "▌Remove Other OPTIMIZER for Better performance,"
sleep 1
ui_print "▌SEARCHING FOR CONFLICTION..."
sleep 0.5
if [ -d $MODDIR/GamersExtreme ]; then
ui_print "▌GamersExtreme Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/GamersExtreme/disable
elif [ -d $MODDIR/ktweak ]; then
ui_print "▌KTweak trash 🗑️ detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/ktweak/disable
elif [ -d $MODDIR/GSMxBNG ]; then
ui_print "▌GSMxBNG Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/GSMxBNG/disable
elif [ -d $MODDIR/FDE ]; then
ui_print "▌FDE.AI Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/FDE/disable
elif [ -d $MODDIR/RTKS ]; then
ui_print "▌RTKS Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/RTKS/disable
elif [ -d $MODDIR/xengine ]; then
ui_print "▌Xengine Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/xengine/disable
elif [ -d $MODDIR/ZeetaaTweaks ]; then
ui_print "▌ZeetaaTweaks Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/ZeetaaTweaks/disable
elif [ -d $MODDIR/PXT ]; then
ui_print "▌PXT Module detected,you wanna boom your device nigga!? im removing it.."
touch $MODDIR/PXT/disable
elif [ -d $MODDIR/lv-gpu-performance ]; then
ui_print "▌Lv-gpu-performance Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/lv-gpu-performance/disable
elif [ -d $MODDIR/R.kashyap ]; then
ui_print "▌Gamers Edition Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/R.kashyap/disable
elif [ -d $MODDIR/ZTS ]; then
ui_print "▌ZTS Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/ZTS/disable
elif [ -d $MODDIR/MAGNETAR ]; then
ui_print "▌MAGNETAR Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/MAGNETAR/disable
elif [ -d $MODDIR/Apollon ]; then
ui_print "▌Apollon Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/Apollon/disable
elif [ -d $MODDIR/Apollon-plus ]; then
ui_print "▌Apollon Plus Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/Apollon-plus/disable
elif [ -d $MODDIR/gameexp ]; then
ui_print "▌Improve Game Xperience Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/gameexp/disable
elif [ -d $MODDIR/lspeed ]; then
ui_print "▌LSpeed Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/lspeed/disable
elif [ -d $MODDIR/fkm_spectrum_injector ]; then
ui_print "▌FKM Injector Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/fkm_spectrum_injector/disable
elif [ -d $MODDIR/KTSR ]; then
ui_print "▌KTSR Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/KSTR/disable
elif [ -d $MODDIR/lazy ]; then
ui_print "▌Lazy Tweaks Module detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/lazy/disable
elif [ -d $MODDIR/injector ]; then
ui_print "▌NFS Injector trash 🗑️ detected, you wanna boom your device nigga!? im removing it.."
touch $MODDIR/injector/disable
elif [ "$(pm list package magnetarapp)" ]; then
ui_print "▌MAGNETAR App has been detected, I recommend removing the app to avoid conflicts."
elif [ "$(pm list package ktweak)" ]; then
ui_print "▌KTweak App trash 🗑️ has been detected, I recommend removing the app to avoid conflicts."
elif [ "$(pm list package lsandroid)" ]; then
ui_print "▌LSpeed App has been detected, I recommend removing the app to avoid conflicts."
elif [ "$(pm list package feravolt)" ]; then
ui_print "▌FDE.AI App has been detected, I recommend removing the app to avoid conflicts."
elif [ "$(pm list package kitana)" ]; then
ui_print "▌Kitana Tweak App has been detected, I recommend removing the app to avoid conflicts."
elif [ "$(pm list package nfs)" ]; then
ui_print "▌NFS Manager App has been detected, I recommend removing the app to avoid conflicts."
fi
sleep 1
ui_print "▌ADDING GAMES TO MAGISKHIDE PLOX WAIT"
  ui_print "▌"
  sleep 1.5
  ui_print "▌ENABLING MAGISKHIDE"
magiskhide disable >/dev/null 2>&1
magiskhide enable >/dev/null 2>&1
magisk --denylist enable >/dev/null 2>&1
sleep 1.5
ui_print "▌MAGISK HIDE ENABLED"
sleep 1.5
ui_print ""
ui_print "▌ADDING GAMES"
am start -a android.intent.action.VIEW -d https://t.me/godtspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
magiskhide add com.tencent.ig >/dev/null 2>&1
magiskhide add com.epicgames.fortnite >/dev/null 2>&1
magiskhide add com.vng.pubgmobile >/dev/null 2>&1
magiskhide add com.pubg.krmobile >/dev/null 2>&1
magiskhide add com.activision.callofduty.shooter >/dev/null 2>&1
magiskhide add com.garena.game.codm >/dev/null 2>&1
magiskhide add com.pubg.newstate >/dev/null 2>&1
magiskhide add com.plato.android >/dev/null 2>&1
magiskhide add com.dts.freefireth >/dev/null 2>&1
magiskhide add com.dts.freefiremax >/dev/null 2>&1
magiskhide add com.kitkagames.fallbuddies >/dev/null 2>&1
magiskhide add com.ea.gp.apexlegendsmobilefps >/dev/null 2>&1
magisk --denylist add com.pubg.newstate >/dev/null 2>&1
magisk --denylist add com.garena.game.codm >/dev/null 2>&1
magisk --denylist add com.activision.callofduty.shooter >/dev/null 2>&1
magisk --denylist add com.pubg.krmobile >/dev/null 2>&1
magisk --denylist add com.epicgames.fortnite >/dev/null 2>&1
magisk --denylist add com.tencent.ig >/dev/null 2>&1
magisk --denylist add com.plato.android >/dev/null 2>&1
magisk --denylist add com.dts.freefireth >/dev/null 2>&1
magisk --denylist add com.dts.freefiremax >/dev/null 2>&1
magisk --denylist add com.kitkagames.fallbuddies >/dev/null 2>&1
magisk --denylist add com.ea.gp.apexlegendsmobilefps >/dev/null 2>&1
sleep 1
ui_print "▌ALL GAMES ADDED SUCCESSFULLY "
sleep 1
ui_print "▌INSTALLING GODSPEED A.I."
unzip -o "$ZIPFILE" 'gsmai/*' -d "$TMPDIR" >&2 && cp -af "$TMPDIR"/gsmai/* "$MODPATH"/config
sleep 3
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
ui_print "▌INSTALLED GODSPEED A.I. "
ui_print "▌A module by @revWhiteShadow "
ui_print "▌support channel @godTspeed | @godspeedmode "
ui_print "▌Visit Our website for more gaming stuffs "
ui_print "▌www.godtspeed.xyz"
ui_print "▌SettingUp Permissions "
ui_print "▌Buy me a Coffee ☕ Plox "
am start -a android.intent.action.VIEW -d https://www.buymeacoffee.com/revWS >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 3

set_permissions() {
set_perm_recursive $MODPATH/config 0 0 0755 0755
set_perm_recursive $MODPATH/system/* 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/bin/fab" 0 0 0755 0755
}
